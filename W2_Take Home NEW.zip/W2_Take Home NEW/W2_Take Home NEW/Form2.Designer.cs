﻿namespace W2_Take_Home_NEW
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_Z = new System.Windows.Forms.Button();
            this.lb_KataAcak = new System.Windows.Forms.Label();
            this.lb_Huruf1 = new System.Windows.Forms.Label();
            this.lb_Huruf5 = new System.Windows.Forms.Label();
            this.lb_Huruf4 = new System.Windows.Forms.Label();
            this.lb_Huruf3 = new System.Windows.Forms.Label();
            this.lb_Huruf2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_W
            // 
            this.btn_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_W.Location = new System.Drawing.Point(177, 236);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(76, 76);
            this.btn_W.TabIndex = 0;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = true;
            this.btn_W.Click += new System.EventHandler(this.btn_W_Click);
            // 
            // btn_A
            // 
            this.btn_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_A.Location = new System.Drawing.Point(132, 318);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(76, 76);
            this.btn_A.TabIndex = 1;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = true;
            this.btn_A.Click += new System.EventHandler(this.btn_A_Click);
            // 
            // btn_Q
            // 
            this.btn_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_Q.Location = new System.Drawing.Point(95, 236);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(76, 76);
            this.btn_Q.TabIndex = 2;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = true;
            this.btn_Q.Click += new System.EventHandler(this.btn_Q_Click);
            // 
            // btn_P
            // 
            this.btn_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_P.Location = new System.Drawing.Point(833, 236);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(76, 76);
            this.btn_P.TabIndex = 3;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = true;
            this.btn_P.Click += new System.EventHandler(this.btn_P_Click);
            // 
            // btn_O
            // 
            this.btn_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_O.Location = new System.Drawing.Point(751, 236);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(76, 76);
            this.btn_O.TabIndex = 4;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = true;
            this.btn_O.Click += new System.EventHandler(this.btn_O_Click);
            // 
            // btn_I
            // 
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_I.Location = new System.Drawing.Point(669, 236);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(76, 76);
            this.btn_I.TabIndex = 5;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = true;
            this.btn_I.Click += new System.EventHandler(this.btn_I_Click);
            // 
            // btn_U
            // 
            this.btn_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_U.Location = new System.Drawing.Point(587, 236);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(76, 76);
            this.btn_U.TabIndex = 6;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = true;
            this.btn_U.Click += new System.EventHandler(this.btn_U_Click);
            // 
            // btn_Y
            // 
            this.btn_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_Y.Location = new System.Drawing.Point(505, 236);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(76, 76);
            this.btn_Y.TabIndex = 7;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = true;
            this.btn_Y.Click += new System.EventHandler(this.btn_Y_Click);
            // 
            // btn_T
            // 
            this.btn_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_T.Location = new System.Drawing.Point(423, 236);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(76, 76);
            this.btn_T.TabIndex = 8;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = true;
            this.btn_T.Click += new System.EventHandler(this.btn_T_Click);
            // 
            // btn_R
            // 
            this.btn_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_R.Location = new System.Drawing.Point(341, 236);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(76, 76);
            this.btn_R.TabIndex = 9;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = true;
            this.btn_R.Click += new System.EventHandler(this.btn_R_Click);
            // 
            // btn_E
            // 
            this.btn_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_E.Location = new System.Drawing.Point(259, 236);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(76, 76);
            this.btn_E.TabIndex = 10;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = true;
            this.btn_E.Click += new System.EventHandler(this.btn_E_Click);
            // 
            // btn_L
            // 
            this.btn_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_L.Location = new System.Drawing.Point(788, 318);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(76, 76);
            this.btn_L.TabIndex = 11;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = true;
            this.btn_L.Click += new System.EventHandler(this.btn_L_Click);
            // 
            // btn_K
            // 
            this.btn_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_K.Location = new System.Drawing.Point(706, 318);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(76, 76);
            this.btn_K.TabIndex = 12;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = true;
            this.btn_K.Click += new System.EventHandler(this.btn_K_Click);
            // 
            // btn_J
            // 
            this.btn_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_J.Location = new System.Drawing.Point(624, 318);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(76, 76);
            this.btn_J.TabIndex = 13;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = true;
            this.btn_J.Click += new System.EventHandler(this.btn_J_Click);
            // 
            // btn_H
            // 
            this.btn_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_H.Location = new System.Drawing.Point(542, 318);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(76, 76);
            this.btn_H.TabIndex = 14;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = true;
            this.btn_H.Click += new System.EventHandler(this.btn_H_Click);
            // 
            // btn_G
            // 
            this.btn_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_G.Location = new System.Drawing.Point(460, 318);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(76, 76);
            this.btn_G.TabIndex = 15;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = true;
            this.btn_G.Click += new System.EventHandler(this.btn_G_Click);
            // 
            // btn_F
            // 
            this.btn_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_F.Location = new System.Drawing.Point(378, 318);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(76, 76);
            this.btn_F.TabIndex = 16;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = true;
            this.btn_F.Click += new System.EventHandler(this.btn_F_Click);
            // 
            // btn_D
            // 
            this.btn_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_D.Location = new System.Drawing.Point(296, 318);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(76, 76);
            this.btn_D.TabIndex = 17;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = true;
            this.btn_D.Click += new System.EventHandler(this.btn_D_Click);
            // 
            // btn_S
            // 
            this.btn_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_S.Location = new System.Drawing.Point(214, 318);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(76, 76);
            this.btn_S.TabIndex = 18;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = true;
            this.btn_S.Click += new System.EventHandler(this.btn_S_Click);
            // 
            // btn_M
            // 
            this.btn_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_M.Location = new System.Drawing.Point(669, 400);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(76, 76);
            this.btn_M.TabIndex = 19;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = true;
            this.btn_M.Click += new System.EventHandler(this.btn_M_Click);
            // 
            // btn_N
            // 
            this.btn_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_N.Location = new System.Drawing.Point(587, 400);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(76, 76);
            this.btn_N.TabIndex = 20;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = true;
            this.btn_N.Click += new System.EventHandler(this.btn_N_Click);
            // 
            // btn_B
            // 
            this.btn_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_B.Location = new System.Drawing.Point(505, 400);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(76, 76);
            this.btn_B.TabIndex = 21;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = true;
            this.btn_B.Click += new System.EventHandler(this.btn_B_Click);
            // 
            // btn_V
            // 
            this.btn_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_V.Location = new System.Drawing.Point(423, 400);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(76, 76);
            this.btn_V.TabIndex = 22;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = true;
            this.btn_V.Click += new System.EventHandler(this.btn_V_Click);
            // 
            // btn_C
            // 
            this.btn_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_C.Location = new System.Drawing.Point(341, 400);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(76, 76);
            this.btn_C.TabIndex = 23;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // btn_X
            // 
            this.btn_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_X.Location = new System.Drawing.Point(259, 400);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(76, 76);
            this.btn_X.TabIndex = 24;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = true;
            this.btn_X.Click += new System.EventHandler(this.btn_X_Click);
            // 
            // btn_Z
            // 
            this.btn_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.btn_Z.Location = new System.Drawing.Point(177, 400);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(76, 76);
            this.btn_Z.TabIndex = 25;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = true;
            this.btn_Z.Click += new System.EventHandler(this.btn_Z_Click);
            // 
            // lb_KataAcak
            // 
            this.lb_KataAcak.AutoSize = true;
            this.lb_KataAcak.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lb_KataAcak.Location = new System.Drawing.Point(866, 46);
            this.lb_KataAcak.Name = "lb_KataAcak";
            this.lb_KataAcak.Size = new System.Drawing.Size(82, 20);
            this.lb_KataAcak.TabIndex = 26;
            this.lb_KataAcak.Text = "Kata Acak";
            // 
            // lb_Huruf1
            // 
            this.lb_Huruf1.AutoSize = true;
            this.lb_Huruf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Huruf1.Location = new System.Drawing.Point(169, 135);
            this.lb_Huruf1.Name = "lb_Huruf1";
            this.lb_Huruf1.Size = new System.Drawing.Size(122, 40);
            this.lb_Huruf1.TabIndex = 27;
            this.lb_Huruf1.Text = "_____";
            // 
            // lb_Huruf5
            // 
            this.lb_Huruf5.AutoSize = true;
            this.lb_Huruf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Huruf5.Location = new System.Drawing.Point(681, 135);
            this.lb_Huruf5.Name = "lb_Huruf5";
            this.lb_Huruf5.Size = new System.Drawing.Size(122, 40);
            this.lb_Huruf5.TabIndex = 28;
            this.lb_Huruf5.Text = "_____";
            // 
            // lb_Huruf4
            // 
            this.lb_Huruf4.AutoSize = true;
            this.lb_Huruf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Huruf4.Location = new System.Drawing.Point(553, 135);
            this.lb_Huruf4.Name = "lb_Huruf4";
            this.lb_Huruf4.Size = new System.Drawing.Size(122, 40);
            this.lb_Huruf4.TabIndex = 29;
            this.lb_Huruf4.Text = "_____";
            // 
            // lb_Huruf3
            // 
            this.lb_Huruf3.AutoSize = true;
            this.lb_Huruf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Huruf3.Location = new System.Drawing.Point(425, 135);
            this.lb_Huruf3.Name = "lb_Huruf3";
            this.lb_Huruf3.Size = new System.Drawing.Size(122, 40);
            this.lb_Huruf3.TabIndex = 30;
            this.lb_Huruf3.Text = "_____";
            // 
            // lb_Huruf2
            // 
            this.lb_Huruf2.AutoSize = true;
            this.lb_Huruf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Huruf2.Location = new System.Drawing.Point(297, 135);
            this.lb_Huruf2.Name = "lb_Huruf2";
            this.lb_Huruf2.Size = new System.Drawing.Size(122, 40);
            this.lb_Huruf2.TabIndex = 31;
            this.lb_Huruf2.Text = "_____";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 649);
            this.Controls.Add(this.lb_Huruf2);
            this.Controls.Add(this.lb_Huruf3);
            this.Controls.Add(this.lb_Huruf4);
            this.Controls.Add(this.lb_Huruf5);
            this.Controls.Add(this.lb_Huruf1);
            this.Controls.Add(this.lb_KataAcak);
            this.Controls.Add(this.btn_Z);
            this.Controls.Add(this.btn_X);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_V);
            this.Controls.Add(this.btn_B);
            this.Controls.Add(this.btn_N);
            this.Controls.Add(this.btn_M);
            this.Controls.Add(this.btn_S);
            this.Controls.Add(this.btn_D);
            this.Controls.Add(this.btn_F);
            this.Controls.Add(this.btn_G);
            this.Controls.Add(this.btn_H);
            this.Controls.Add(this.btn_J);
            this.Controls.Add(this.btn_K);
            this.Controls.Add(this.btn_L);
            this.Controls.Add(this.btn_E);
            this.Controls.Add(this.btn_R);
            this.Controls.Add(this.btn_T);
            this.Controls.Add(this.btn_Y);
            this.Controls.Add(this.btn_U);
            this.Controls.Add(this.btn_I);
            this.Controls.Add(this.btn_O);
            this.Controls.Add(this.btn_P);
            this.Controls.Add(this.btn_Q);
            this.Controls.Add(this.btn_A);
            this.Controls.Add(this.btn_W);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Label lb_KataAcak;
        private System.Windows.Forms.Label lb_Huruf1;
        private System.Windows.Forms.Label lb_Huruf5;
        private System.Windows.Forms.Label lb_Huruf4;
        private System.Windows.Forms.Label lb_Huruf3;
        private System.Windows.Forms.Label lb_Huruf2;
    }
}